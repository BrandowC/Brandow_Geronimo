import { Controller, Get, Param } from '@nestjs/common';
import { ProductsService } from './products.service';

@Controller('products')
export class ProductsController {

    constructor(
        private readonly productService: ProductsService,
    ){}

    @Get()
    getAllProducts(){
        return this.productService.findAll();
    }

    @Get('/id')
    getProductsById(@Param('id') id: string) {
        return this.productService.findOneById(+id);
    }
}
